package com.cg.obs.service;


import java.sql.Date;
import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.dao.AdminDaoImpl;
import com.cg.obs.dao.IAdminDao;
import com.cg.obs.dao.IUserDAO;
import com.cg.obs.dao.UserDAOImpl;
import com.cg.obs.exception.UserException;

public class UserServiceImpl implements IUserService {

	IUserDAO userDao;
	IAdminDao adminDao;
	public UserServiceImpl() {
		userDao=new UserDAOImpl();
		adminDao=new AdminDaoImpl();
	}
	
	
	
	@Override
	public Users getUser(int id) throws UserException {
		
		return userDao.getUser(id);
	}

	@Override
	public Admin getAdmin(String id) throws UserException {
		
		return adminDao.getAdmin(id);
	}



	@Override
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
		
		System.out.println("In service");
		return userDao.getMiniTransactions(accountno);
	}

	
	@Override
	public List<Transactions> getDetailedTransactions(Long accountno,Date fromDate,Date toDate) throws UserException
	{
		return userDao.getDetailedTransactions(accountno, fromDate, toDate);
		
}

	@Override
	public int getCustomerId(Long accountno) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getCustomerId(accountno);
	}



	@Override
	public Customer getCustomer(int customerid) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getCustomer(customerid);
	
	}
	
	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
	
		userDao.updateCustomerDetails(customer);
	}


	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		return userDao.requestService(services);
	}



	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
		// TODO Auto-generated method stub
		return userDao.fundTransfer(transferInfo);
	}



	@Override
	public void changePassword(Users user) throws UserException {

		userDao.changePassword(user);
		
	}



	@Override
	public void updateLockStatus(int userid) throws UserException {
		
		userDao.updateLockStatus(userid);
		
	}



	@Override
	public List<Payee> getPayee(long accountid) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getPayee(accountid);
	}



	@Override
	public void insertPayee(Payee payee) throws UserException {
		// TODO Auto-generated method stub
		userDao.insertPayee(payee);
	}



	@Override
	public AccountMaster getAccount(long accountno) {
		// TODO Auto-generated method stub
		return userDao.getAccount(accountno);
	}

}


